import { Component } from '@angular/core';

@Component({
  selector: 'lib-my-lib',
  template: ` <p>my-lib works!</p> `,
  styles: [],
})
export class MyLibComponent {}
